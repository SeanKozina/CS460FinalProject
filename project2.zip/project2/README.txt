1- make 

2- ./tokenizer

3- check result :D