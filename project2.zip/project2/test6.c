// ***************************************************
// * CS460: Programming Assignment 2: Test Program 6 *
// ***************************************************
procedure main (void)
{
  int counter;

  counter = 1f;
  printf ("counter = %d\n, counter);
}
