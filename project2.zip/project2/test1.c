// ***************************************************
// * CS460: Programming Assignment 2: Test Program 1 *
// ***************************************************
procedure main (void)
{
  int counter;

  counter = -2;
  printf ("counter = %d\n", counter);
}
